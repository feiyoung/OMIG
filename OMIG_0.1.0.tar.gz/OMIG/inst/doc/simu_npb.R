## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
#  library(OMIG)

## ----eval = FALSE-------------------------------------------------------------
#  q <- 4
#  type <- "npb"
#  n <- 100; p <- 100; rho <- 2; mis_vec <- c(0.1, 0.2, 0.3)
#  dat <- gendata(q = q, n=n, p=p, type= type, rho=c(rho, 0.5), mis_vec= mis_vec)

## ----eval = FALSE-------------------------------------------------------------
#  print(str(dat))
#  print(dat$XmisList[[1]][1:5,1:10])
#  print(dat$XmisList[[2]][1:5,1:10])

## ----eval = FALSE-------------------------------------------------------------
#  q <- 4
#  group <- dat$group;
#  hist.summary= NULL;
#  lambda=1;
#  verbose=TRUE
#  types <- c('gaussian', 'poisson', "binomial")
#  suppressWarnings(res <- OMIG(Xmis_new=dat$Xmis, q=q,  group=dat$group, type= types, hist.summary= NULL, lambda=lambda,  verbose=TRUE))

## ----eval = FALSE-------------------------------------------------------------
#  err_omig <- NAE(res$hX, dat$X, dat$Xmis, dat$group)

## ----eval = FALSE-------------------------------------------------------------
#  ## compare with the offline method MIG
#  suppressWarnings(res_mig <- OrMIG(dat$Xmis, dat$group, type= types, q, algorithm = 'AM', verbose = F))
#  err_am <- NAE(res_mig$hX, dat$X,  dat$Xmis, dat$group)
#  
#  res_mig <- OrMIG(dat$Xmis, dat$group, type= types, q, algorithm = 'VEM', verbose = F)
#  err_vem <- NAE(res_mig$hX, dat$X,  dat$Xmis, dat$group)

## ----eval = FALSE-------------------------------------------------------------
#  ## compare with the offline method MIG
#  res_jms <- LFM.JMS(dat$Xmis, q)
#  err_jms <- NAE(res_jms, dat$X,  dat$Xmis, dat$group)
#  
#  res_xp <- LFM.XP(dat$Xmis, q)
#  err_xp <- NAE(res_xp, dat$X,  dat$Xmis, dat$group)

## ----eval = FALSE-------------------------------------------------------------
#  df <- data.frame(NAE = c(err_omig, err_am, err_vem, err_jms, err_xp), Method=rep(c("OMIG", "AM", "VEM", "LFM-EM", "LFM-PR"), each=3), Type = rep(c("Continuous", "Count", "Binary"), length=15))
#  df$Method <- factor(df$Method, levels=c("OMIG", "AM", "VEM", "LFM-EM", "LFM-PR"))
#  library(ggplot2)
#  ggplot(df, aes(x=Type, y=NAE, fill=Method)) + geom_bar(position = "dodge", stat="identity",width = 0.5)

## ----eval = FALSE-------------------------------------------------------------
#  hq <- selectFacNumber(dat$Xmis, group=group, types=types, q_set=1:6)
#  print(c(q_est=hq, q_true=q))

## ----eval = FALSE-------------------------------------------------------------
#  hq <- selectFacNumber(dat$Xmis, group=group, types=types, select_method='IC')
#  print(c(q_est=hq, q_true=q))

## ----eval = FALSE-------------------------------------------------------------
#  n2 <- 80
#  dat <- gendata(q = q, n=n2, p=p, type= type, rho=c(rho, 0.6), mis_vec= mis_vec)

## ----eval = FALSE-------------------------------------------------------------
#  res2 <- OMIG(Xmis_new=dat$Xmis, q,  dat$group, types, hist.summary= res$hist.summary, lambda=1,
#               verbose=TRUE)
#  err_omig <- NAE(res2$hX, dat$X, dat$Xmis, dat$group)

## ----eval = FALSE-------------------------------------------------------------
#  res_mig <- OrMIG(dat$Xmis, dat$group, types, q, algorithm = "VEM", verbose = F)
#  err_vem <- NAE(res_mig$hX, dat$X,  dat$Xmis, dat$group)
#  suppressWarnings(res_mig2 <- OrMIG(dat$Xmis, dat$group, types, q, algorithm = "AM", verbose = F))
#  err_am <-NAE(res_mig2$hX, dat$X,  dat$Xmis, dat$group)

## ----eval = FALSE-------------------------------------------------------------
#  df <- data.frame(NAE = c(err_omig, err_am, err_vem), Method=rep(c("OMIG", "AM", "VEM"), each=3), Type = rep(c("Continuous", "Count", "Binary"), length=9))
#  df$Method <- factor(df$Method, levels=c("OMIG", "AM", "VEM"))
#  ggplot(df, aes(x=Type, y=NAE, fill=Method)) + geom_bar(position = "dodge", stat="identity",width = 0.5)

## ----eval = FALSE-------------------------------------------------------------
#  n2 <- 60
#  dat <- gendata(q = q, n=n2, p=p, type= type, rho=c(rho, 0.6), mis_vec= mis_vec, seed=100)

## ----eval = FALSE-------------------------------------------------------------
#  res3 <- OMIG(Xmis_new=dat$Xmis, q=q,  group=dat$group, types, hist.summary= res2$hist.summary)
#  err_omig <- NAE(res3$hX, dat$X, dat$Xmis, dat$group)

## ----eval = FALSE-------------------------------------------------------------
#  res_mig <- OrMIG(dat$Xmis, dat$group, types, q, algorithm = "VEM", verbose = F)
#  err_vem <- NAE(res_mig$hX, dat$X,  dat$Xmis, dat$group)
#  suppressWarnings(res_mig2 <- OrMIG(dat$Xmis, dat$group, types, q, algorithm = "AM", verbose = F))
#  err_am <-NAE(res_mig2$hX, dat$X,  dat$Xmis, dat$group)

## ----eval = FALSE-------------------------------------------------------------
#  df <- data.frame(NAE = c(err_omig, err_am, err_vem), Method=rep(c("OMIG", "AM", "VEM"), each=3), Type = rep(c("Continuous", "Count", "Binary"), length=9))
#  df$Method <- factor(df$Method, levels=c("OMIG", "AM", "VEM"))
#  ggplot(df, aes(x=Type, y=NAE, fill=Method)) + geom_bar(position = "dodge", stat="identity",width = 0.5)

## ----eval = FALSE-------------------------------------------------------------
#  library(glmnet)
#  set.seed(1)
#  lm1 <- glmnet(x=res3$hX[,-1], y= res3$hX[,1], alpha=0.5)
#  plot(lm1)

## -----------------------------------------------------------------------------
sessionInfo()

